import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getProjects = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const projects = await prisma.project.findMany();
    res.json(projects);
  } catch (error: any) {
    res
      .status(500)
      .json({ message: `Error retrieving projects: ${error.message}` });
  }
};

export const createProject = async (req: Request, res: Response): Promise<void> => {
  const { name, description, startDate, endDate, status = "New" } = req.body;
  try {
    const newProject = await prisma.project.create({
      data: {
        name,
        description,
        startDate,
        endDate,
        status,
      },
    });
    res.status(201).json(newProject);
  } catch (error: any) {
    console.error("Error creating project:", error);  // Log the complete error
    res.status(500).json({ message: `Error creating project: ${error.message}` });
  }
};


export const updateProjectStatus = async (
  req: Request,
  res: Response
): Promise<void> => {
  const { projectId } = req.params;
  const { status } = req.body;
  try {
    const updatedProject = await prisma.project.update({
      where: {
        id: Number(projectId),
      },
      data: {
        status: status,
      },
    });
    res.json(updatedProject);
  } catch (error: any) {
    res.status(500).json({ message: `Error updating Project: ${error.message}` });
  }
};